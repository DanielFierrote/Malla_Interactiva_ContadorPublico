# Malla Interactiva — Contador Público

Malla de la carrera con correlativas. Hacé clic en una materia disponible para marcarla como aprobada (otro clic la desmarca). Las que dependen de ella se desbloquean solas.

## Archivos

- `index.html`: la página
- `estilo.css`: el diseño
- `script.js`: el funcionamiento (malla, guía de correlativas y panel Administrar)
- `datos.js`: **las materias, los años y las correlativas**. Es lo único que cambia cuando editás la malla.

## Publicar en GitHub Pages

1. Subí estos 4 archivos a tu repositorio (si ya tenías la malla, reemplazá los viejos).
2. En el repositorio, entrá a **Settings → Pages**, elegí la rama `main` y la carpeta `/ (root)`, y guardá.
3. En un minuto queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Editar la malla

Tocá **⚙ Administrar**. Solo desde ahí se puede editar: nombres, códigos, correlativas, mover materias, agregar o borrar años, cuatrimestres y materias.

## Que los cambios se guarden solos en GitHub (configurar una vez)

Así, todo lo que se marque o edite en la página se sube solo al repositorio y se ve igual en cualquier compu o celu.

**1. Crear el token (lo hace el dueño del repositorio, una sola vez):**
1. En GitHub: foto de perfil → **Settings** → **Developer settings** → **Personal access tokens** → **Fine-grained tokens** → **Generate new token**.
2. Nombre: `malla`. Vencimiento: el más largo que te deje.
3. **Repository access** → *Only select repositories* → elegí el repositorio de la malla.
4. **Permissions** → *Repository permissions* → **Contents: Read and write**.
5. **Generate token** y copialo (empieza con `github_pat_`).

**2. Pegarlo en la página (en cada celu o compu donde se use):**
1. Abrí la página → **⚙ Administrar** → **Guardar en GitHub**.
2. Usuario y repositorio se completan solos. Pegá el token.
3. Dejá tildado *Guardar en GitHub automáticamente*.

Listo: cada cambio se sube unos segundos después y aparece en la página en 1 o 2 minutos.

> El token queda guardado solo en ese navegador, no en el repositorio. Nunca lo pegues dentro de los archivos. Si se pierde o vence, generá otro y volvé a pegarlo.

Sin token también funciona: los cambios quedan en el navegador, y podés tocar **Descargar datos.js** y subirlo a mano.

## Notas

En **⚙ Administrar → Mis notas** aparecen las materias aprobadas para cargarles la nota. La nota se ve al lado de cada materia en la malla y arriba se calcula el promedio.

## Guía de correlativas

El botón **Guía de correlativas** la prende o la apaga. Con la guía prendida, al pasar el mouse por una materia (en el celu, con el primer toque) se marcan en violeta las materias que necesita y en rosa las que habilita.
